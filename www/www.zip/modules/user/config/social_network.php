<?php

$config['networks'] = array(
	'behance',
	'blogger',
	'facebook',
	'last.fm',
	'myspace',
	'skype',
	'twitter',
	'youtube',
	'vimeo',
	'livejournal',
	'yahoo',
	'picasa'
);