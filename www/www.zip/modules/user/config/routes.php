<?php
$config['xd_receiver.html'] = 'user/xd_receiver';
$config['user/logout'] = 'user/logout';
$config['user/profile'] = 'user/profile';
$config['user/login'] = 'user/login';
$config['user/register'] = 'user/register';
$config['user/registered'] = 'user/registered';
$config['user/reminder'] = 'user/reminder';
$config['user/remind'] = 'user/remind';
$config['user/edit'] = 'user/edit';
$config['user/social_network'] = 'user/social_network';
$config['user/edit_tags'] = 'user/edit_tags';
$config['user/avatar'] = 'user/avatar';
$config['user/avatar_upload'] = 'user/avatar_upload';
$config['user/newemail'] = 'user/newemail';
$config['user/newpass'] = 'user/newpass';
$config['user/activate'] = 'user/activate';

$config['user/fbregister'] = 'user/fbregister';
$config['user/vkregister'] = 'user/vkregister';
$config['user/newnickname'] = 'user/newnickname';
$config['user/search'] = 'user/search';
$config['user/login_baloon'] = 'user/login_baloon';
$config['user/mojo_login'] = 'user/mojo_login';
$config['user/twitter_baloon'] = 'user/twitter_baloon';
$config['user/stopTwitterSync'] = 'user/stopTwitterSync';

$config['user/invite'] = 'user/invite';

//$config['user/get_tags/([a-zA-Z0-9-_.]+)'] = 'user/get_tags/$1';
//$config['user/([a-zA-Z0-9-_.@]+)/friends'] = 'user/friends/$1';
//$config['user/([a-zA-Z0-9-_.@]+)'] = 'user/profile/$1';