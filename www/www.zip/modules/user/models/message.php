<?php 
class Message_Model extends ORM{
	protected $has_one  = array('user');	
	
}
?>