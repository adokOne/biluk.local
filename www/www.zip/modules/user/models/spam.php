<?php 
class Spam_Model extends ORM{
	protected $has_one  = array('user');	
	
}
?>