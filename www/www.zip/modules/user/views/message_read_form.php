<div class="b_shadow">
    <div id="message_form" class="b_popup">
    <a href="#" id="close" style="position: absolute;right: 5px;top: 5px;"><img src="/images/close.1.png"></a>
      <h3><?php echo $message->theme;?></h3>
      <ul class="form_list">
        <li>          
          <p class="message_text">
          <?php echo $message->text?>
          </p>
        </li>
      </ul>
      <div class="cc"></div>
    </div><!-- b_popup -->
  </div>
  