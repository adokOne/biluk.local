
  <div class="b_shadow">
	    <div class="b_popup">
	      <h3 style="text-align: center;padding: 10px;"><?php echo $text?></h3>
	      <div class="cc"></div>
	    </div><!-- b_popup -->
  </div><!-- b_shadow -->