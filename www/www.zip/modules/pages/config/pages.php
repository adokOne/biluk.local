<?php

$config = array
(
	'pagination' => array('uri_segment'    => 'page',
						  'items_per_page' => 50,
						  'style'          => 'digg',
						  'auto_hide'      => TRUE),					  

	'date_format' => 'd F'
);


