<?php 
class Contact_Model extends ORM{
	
	
}