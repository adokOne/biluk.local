<?php
 
$lang = array(
	
	"err_NickLen"		=>	"Неверная длина ника пользователя",
	"err_NickFormat"	=>	"Неверный формат ника пользователя",
	"err_NickUniq"		=>	"Ник пользователя должен быть уникальным",
	"err_EmailFormat"	=>	"Неверний формат адресса електронной почты",
	"err_EmailUniq"		=>	"E-mail / OpenID пользователя должен быть уникальным",
	"err_PasswFormat"	=>	"Неверный формат пароля пользователя",
	"err_Phonenull"		=>	"Незаданий пароль пользователя",
	"err_PhoneFormat"	=>	"Неверний формат номера телефона",
	"err_correct"		=>	"Введите коректные данные",
	"err_re_password"	=>	"Неверный повтор пароля",
	"err_Save"			=>	"Возникла ошибка при сохранении данных",
	
	"info"			=> "Information",
	"err"			=> "Error",
	"not_modify"	=> "Data not modified",
	"question_del"	=> "Do you really want to delete selected items?",
	
	
	"notSelElement"	=> "You did not select anything",
	"wait"			=>	"Wait...",
	
	"email"		=>	"E-mail",
	"password"	=>	"Password",
	"re_password"	=>	"Retype password",
	"date_reg"		=>	"Registered",
	"last_login"	=>	"Last Login",
	"type"			=>  "Type",
	
	"selGroupRoles"		=>	"Вибрать группу...",
	"selGroupBtn"		=>	"Установить роли группы",
	
	
	
	"block_expired"	=>	"Дата завершения блокировки",
	"active"		=>	"Active",
	
	"name"		=>	"Name",
	"desc"		=>	"Description",
	"sel_unsel"	=>	"Select/Unselect",	
	
	"roles"		=>	"Roles",
	"groups"	=>	"Groups",
	"save"		=>	"Save",
	"save1"		=>	"Set",
	"cancel"	=>	"Cancel",
	
	
	"save_sucs"		=>	"Save Successful",
	"new_passw"		=>	"New password",	
	"new_passw_sucs"	=>	"New password succesfuly set",
	
	"min"		=>	"Min",		
	"max"		=>	"Max",		

	
	"dateRegMin"	=>	"Дата регистрации (min)",
	"dateRegMax"	=>	"Дата регистрации (max)",
	"dateLastLogMin"	=>	"Дата посл.логина (min)",
	"dateLastLogMax"	=>	"Дата посл.логина (max)",
	"RatingMin"	=>	"Рейтинг (min)",
	"RatingMax"	=>	"Рейтинг (max)",
	"CntUploadMin"	=>	"Кол-во загрузок (min)",
	"CntUploadMax"	=>	"Кол-во загрузок (max)",
	"CntCommentMin"	=>	"Кол-во комментариев (min)",
	"CntCommentMax"	=>	"Кол-во комментариев (max)",	
	"UserUnroles"	=>	"Пользователи без ролей",
	"UserUngroups"	=>	"Пользователи без груп",
	
	
	"fltrSets"	=>	"Установка параметров фильтрации",
	"fltrAll"	=>	"Общие",
	"fltrDateReg"	=>	"Дата регистрации",
	"fltrRating"	=>	"Рейтинг",
	"fltrComments"	=>	"Кол-во комментариев",	
	"fltrLastLog"	=>	"Дата последнего логина",
	"fltrUploads"	=>	"Кол-во загрузок",
	"fltrUnRoles"	=>	"Пользователи без ролей",
	"fltrUnGroups"	=>	"Пользователи без груп",	
	"fltrClear"	=>	"Очистить параметры фильтрации",
	"fltrSet"	=>	"Установить параметры фильтрации",
	"fltrNoSelect"	=>	"Параметры фильтрации не установленны",
	
	
	"addUser"	=>	"Add",
	"edit"	=>	"Edit",
	"selOneElemente"	=>	"Select only one element",
	
	"setNewPassw"	=>	"Set New Password",	
	"removeSel"	=>	"Delete selected",
	"filter"	=>	"Фильтрация",
	"clearFilter"	=>	"Очистить фильтр",
	"setRoles"	=>	"Установить роли",
	
	"elements"	=>	"Items {0} - {1} of {2}",
	"empty"	=>	"Empty...",
	

	"users"	=>	"Users",
	"users_list"	=>	"Users list",
	"filterMain"	=>	"Параметры фильтрации",
	
	"setRolesWnd"	=>	"Установка набора ролей для пользователей",
	"setRoles_add"	=>	"Add",
	"setRoles_del"	=>	"Delete",
	"setRoles_groupNoSelected"	=>	"Группа не выбрана",
	"setRoles_sucs"	=>	"Roles set succesfuly",
	
	
	"paym_ID"	=> "ID",
	"payms_phone"	=> "Телефон",
	"payms_summ"	=> "Сумма",
	"payms_date"	=> "Дата проплаты",
	"payms_code"	=> "Код",
	"payms_sms_phone"	=> "СМС номер",

	"accounttype"  => "Accounttype",
	'activated'   => 'Activated'
	
);	