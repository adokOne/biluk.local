var Get_City = function (){
	mainTabPanel.load({
				url: "/admin/cities",
				params: {
					method: 'post'
				},
	 			scripts: true,
	 			text: "Загрузка"
	});
}