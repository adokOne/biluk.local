{
            xtype:'panel',
            title:'Карта',
            region:'north',
            collapsed:false,
            animCollapse:false,
            collapsible:true,
            bodyStyle:'padding:0;margin:0;',
            height:400,
            html:'<div id="google_map" style="height: 375px;"></div>',
            anchor:'100%'
},