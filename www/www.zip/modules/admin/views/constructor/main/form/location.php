        {
            id: 'locationDefault',
            xtype: 'locationselect',
            url: '<?php echo $url ?>/location',
            prefix: '',
            collapsible: true,
            hideBorders:true,
            title: 'Адрес',
            //cache: globalCache,
            autoHeight: true,
            anchor:'95%'
        },