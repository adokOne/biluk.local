	{
        tooltip:'Добавить',
        iconCls:'add',
        disabled:false,
        id:'itemsAdd',
        handler:itemsAdd
    }, {
        tooltip:'Удалить выделенные',
        iconCls:'remove',
        disabled:true,
        id:'itemsRemove',
        handler:itemsRemove
    }, {
        tooltip:'Сохранить изменения',
        iconCls:'save',
        disabled:true,
        id:'itemsSave',        
        handler:itemsSave
    },{
        tooltip:'Типы самолетов',
        iconCls:'ico_news',
        disabled:false,
        id:'Get_Type',
        handler:Get_Type
    },{
        tooltip:'Модификации самолетов',
        iconCls:'ico_sitesettings',
        disabled:false,
        id:'Get_Mod',
        handler:Get_Mod
    }



