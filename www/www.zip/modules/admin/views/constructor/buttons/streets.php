	{
        tooltip:'Додати',
        iconCls:'add',
        disabled:false,
        id:'itemsAdd',
        handler:additemStreet
    }, {
        tooltip:'Видалити',
        iconCls:'remove',
        disabled:true,
        id:'itemsRemove',
        handler:itemsRemove
    }, {
        tooltip:'Зберігти',
        iconCls:'save',
        disabled:true,
        id:'itemsSave',        
        handler:itemsSave
    }



