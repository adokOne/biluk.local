<?php

class Module_Model extends ORM_Tree {
	
	protected $ORM_Tree_children = "modules";
	//protected $parent_key = 'parent_id';
	
}