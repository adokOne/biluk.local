<?php defined('SYSPATH') or die('No direct script access.');

class History_Admin extends Constructor
{
    protected $item_table   = 'history';
    protected $orderby      = 'id';
    protected $order_dir    = 'DESC';
    protected $use_tree     = FALSE;
    protected $use_form     = FALSE;
    protected $use_combo    = FALSE;
    protected $use_logo     = FALSE;
    protected $multi_lang   = TRUE;
	
   
    protected $grid_columns = array(
        "id",
    	"status",

    );
    
    protected $lang_field = array (
    		'name'
    );    
}