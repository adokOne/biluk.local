<?php defined('SYSPATH') or die('No direct script access.');

class Countries_Admin extends Constructor
{
    protected $item_table   = 'countries';
    protected $orderby      = 'id';
    protected $order_dir    = 'DESC';
    protected $buttons      = TRUE;
    protected $multi_lang   = TRUE;
    protected $use_form     = FALSE;
	
    protected $Stores=array("Country");
    
    protected $grid_columns = array(
        "id",
    	"status"
        
    );
    
    protected $lang_field = array (
    		'name'
    );
    
}