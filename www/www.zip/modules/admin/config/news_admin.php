<?php

$config = array(	
	'title' => 'Новини',
	'icon_cls' => 'ico_news',
	'img_width' => 200,
	'img_height' => 100,
	'logo_path'=>"http://".Kohana::config('config.site_domain')."/upload/news/"
);