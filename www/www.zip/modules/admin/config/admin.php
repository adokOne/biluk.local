<?php

$config['actual_topic'] = array
(
	"photo_limit" 	=> 10,
	"video_limit"	=> 10,
	"albums_limit" 	=> 10,
	"news_limit" 	=> 10
);
	
?>