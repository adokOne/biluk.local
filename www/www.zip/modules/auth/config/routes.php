<?php defined('SYSPATH') OR die('No direct access allowed.');

$config['event/([0-9]+)'] = 'calendar/event/$1';
$config['location/([0-9]+)'] = 'calendar/location/$1';
$config['user/([0-9]+)'] = 'calendar/user/$1';

