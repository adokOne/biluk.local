<?php 
class News_Lang_Model extends ORM{
	protected $has_one  = array('new');	
}