<?php
$config['sizes'] = array
(
array('width' => 500, 'height' => 500, 'prefix' => 'r_', 'crop' => true, 'watermark' => false),
array('width' => 320, 'height' => 211, 'prefix' => 'b_', 'crop' => true, 'watermark' => false),
array('width' => 257, 'height' => 194, 'prefix' => 'h_', 'crop' => false, 'watermark' => false),
array('width' => 219, 'height' => 146, 'prefix' => 'm_', 'crop' => true, 'watermark' => false),
array('width' => 79, 'height' => 52, 'prefix' => 's_', 'crop' => true, 'watermark' => false)
);