<?php

$config['news'] = array
(
	"count_per_page" 		=> 5,
	"last_news_count"		=> 3,
	"last_telegraph_count" 	=> 5,
	"actual_topics_count" 	=> 10,
);
array(
	'logo_folder' => '/upload/news/',
	'logo_path'=>"/upload/news/"
	)
	
?>