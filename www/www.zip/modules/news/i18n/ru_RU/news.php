<?php 
	$lang['news']= array(
		"spott_telegraph_title" => "споттерский телеграф",
		"main_news" => "ГЛАВНЫЕ НОВОСТИ",
		"actual_topic_title" => "актуальная тема",
		"show_all" => "показать все",
	);
?>