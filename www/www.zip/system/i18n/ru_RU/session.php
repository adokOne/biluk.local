<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'Имя сессии, %s, некорректно. Оно должно состоять только из буквенно-цифровых символов, и, как минимум, одной буквы.',
);
