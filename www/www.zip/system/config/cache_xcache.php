<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * @package  Cache:Xcache
 *
 * Xcache administrator username.
 */
$config['PHP_AUTH_USER'] = 'kohana';

/**
 * Xcache administrator password.
 */
$config['PHP_AUTH_PW'] = 'kohana';
